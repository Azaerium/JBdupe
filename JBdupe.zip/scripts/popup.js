document.addEventListener('DOMContentLoaded', () => {
    // Select all buttons by their IDs
    const signInBtn = document.getElementById('sign-in');
    const pairBtn = document.getElementById('pair-jb');
    const completePairingBtn = document.getElementById('complete-pairing');
    const launchBtn = document.getElementById('launch-jailbreak');
    const applyDupeBtn = document.getElementById('apply-dupe');
    const uninjectBtn = document.getElementById('uninject');

    // 1. Sign In
    signInBtn.addEventListener('click', () => {
        alert("Sign into the account with the items you want to dupe.\nNOTE: This must be your main account or the dupe won't work.");
        window.open('https://www.roblox.com/home', '_blank');
    });

    // 2. Start Pairing
    pairBtn.addEventListener('click', () => {
        alert("Successfully started pairing!");
    });

    // 3. Complete Pairing
    completePairingBtn.addEventListener('click', () => {
        alert("Do NOT:\nSign out of the Roblox site.\nOpen Roblox/Jailbreak.\n\nAt all within the next 30 minutes for pairing to complete successfully.");
    });

    // 4. Launch Jailbreak
    launchBtn.addEventListener('click', () => {
        alert("You must wait for pairing to complete before launching Jailbreak.\nIf you have waited 30 minutes, retry the previous steps.");
    });

    // Apply Dupe
    applyDupeBtn.addEventListener('click', () => {
        alert("Error: Jailbreak instance not found.\nComplete all the previous steps in order.");
    });

    // Uninject
    uninjectBtn.addEventListener('click', () => {
        alert("Error: Not injected.");
    });
});