document.addEventListener('DOMContentLoaded', () => {
  const launchBtn = document.getElementById('launch-jailbreak');
  const injectDuperBtn = document.getElementById('inject-duper');
  const freezeTradeBtn = document.getElementById('freeze-trade');
  const autoAcceptBtn = document.getElementById('auto-accept');
  const silentLockTradeBtn = document.getElementById('silent-lock-trade');
  const injectScriptBtn = document.getElementById('inject-script');

  function dupeAlert() {
    alert("Error: 445\nJBdupe only functions on main accounts and does not work on any obtainable or cosmetic items.\nPlease sign into your main account and reload the JBdupe extension for full functionality.");
  }

  launchBtn.addEventListener('click', () => {
    location.href = 'roblox://placeId=606849621';
  });

  [injectDuperBtn, freezeTradeBtn, autoAcceptBtn, silentLockTradeBtn, injectScriptBtn].forEach(btn => {
    btn.addEventListener('click', dupeAlert);
  });
});
